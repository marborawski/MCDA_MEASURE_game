function [S]=TOPSIS(E,W,PrefDirection,p)
%TOPIS function

%Normalization
  n = sqrt(sum(E.*E));
	for ii=1:size(E,1)
		for jj=1:size(E,2)
      E(ii,jj) = E(ii,jj)/n(jj);
		end
	end
%Weight
	for ii=1:size(E,1)
		for jj=1:size(E,2)
      E(ii,jj) = E(ii,jj)*W(jj);
		end
	end
  
  start = 1;
  for ii = 1:size(E,1)
    if start == 1
      vPlus = E(ii,:);
      vMinus = E(ii,:);
      start = 0;
    else
      for jj = 1:size(E,2)
        if PrefDirection(jj) == 1
          if E(ii,jj) > vPlus(jj)
            vPlus(jj) = E(ii,jj);
          end
          if E(ii,jj) < vMinus(jj)
            vMinus(jj) = E(ii,jj);
          end
          else
          if E(ii,jj) < vPlus(jj)
            vPlus(jj) = E(ii,jj);
          end
          if E(ii,jj) > vMinus(jj)
            vMinus(jj) = E(ii,jj);
          end
        end
      end
    end
  end
  
  dPlus = zeros(1,size(E,1));
  dMinus = zeros(1,size(E,1));
  for ii = 1:size(E,1)
    dPlus(ii) = sum(abs(E(ii,:)-vPlus).^p)^(1/p);
    dMinus(ii) = sum(abs(E(ii,:)-vMinus).^p)^(1/p);
  end

  S = dMinus./(dPlus - dMinus);
  
end
