function result = NumberToName(array, names)
  result = cell(size(array));
  for ii = 1:size(array,1)
    for jj = 1:size(array,2)
      result{ii,jj}.name = names{array(ii,jj)};
    end
  end
end