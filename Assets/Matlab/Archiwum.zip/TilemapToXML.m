function txt = TilemapToXML(tilemap)
  txt = sprintf('\t<Table>');
  for ii = 1:size(tilemap,1)
    txt = [txt sprintf('\t\t<Row>')];
    for jj = 1:size(tilemap,2)
      txt = [txt sprintf('\t\t\t<Cell>')];
      txt = [txt sprintf('<Data')];       
      if isfield(tilemap{ii,jj},'type')
       txt = [txt sprintf(' type="%s"',tilemap{ii,jj}.type)];     
      end
      txt = [txt sprintf('>')];       
      txt = [txt sprintf('%s',tilemap{ii,jj}.name)];      
      txt = [txt sprintf('</Data>')];
      txt = [txt sprintf('</Cell>')];
    end
    txt = [txt sprintf('\t\t</Row>')];
  end
  txt = [txt sprintf('\t</Table>')];

end