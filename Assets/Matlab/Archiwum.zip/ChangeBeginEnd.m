function result = ChangeBeginEnd(array)
  result = array;
  for ii = 1:size(array,1)
    for jj = 1:size(array,2)
      if strcmp(array{ii,jj}.name,'Begin') == 1
        result{ii,jj}.name = 'Water';
        result{ii,jj}.type = array{ii,jj}.name;
      end
      if strcmp(array{ii,jj}.name,'End') == 1
        result{ii,jj}.name = 'Water';
        result{ii,jj}.type = array{ii,jj}.name;
      end
    end
  end
end