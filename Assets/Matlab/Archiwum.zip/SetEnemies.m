function txt = SetEnemies(no,count,speed,startHealth,armour,cost,destroyCoins,coinsToEnd,type, tag) 
    txt = sprintf('\t<SetEnemies>');  
    txt = [txt, sprintf('\t\t<Enemy no="%d" count="%d" speed="%d" startHealth="%d" armour="%d" cost="%d" destroyCoins="%d" coinsToEnd="%d" type="%s" tag="%s">',no,count,speed,startHealth,armour,cost,destroyCoins,coinsToEnd,type, tag)];  
    txt = [txt, sprintf('\t\t</Enemy>')];
    txt = [txt, sprintf('\t</SetEnemies>')];
end