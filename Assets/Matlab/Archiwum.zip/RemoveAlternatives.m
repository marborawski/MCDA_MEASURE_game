function [E,W,PrefDirection] = RemoveAlternatives(E,W,PrefDirection)
  tmp = std(E);
  p = find(abs(tmp) >= 0.000000000000001);
  E = E(:,p);
  W = W(p);
  PrefDirection = PrefDirection(p);
end