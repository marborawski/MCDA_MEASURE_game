function txt = AddTower(noTower,x,y)
    txt = sprintf('\t<AddTower no="%d" x="%d" y="%d">',noTower,x,y);  
    txt = [txt, sprintf('\t</AddTower>')];
end