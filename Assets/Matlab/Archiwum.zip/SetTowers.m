function txt = SetTowers(no,count,speed,rateofFire,force,bulletStrength,cost,type, tag)
    txt = sprintf('\t<SetTowers>');  
    txt = [txt, sprintf('\t\t<Tower no="%d" count="%d" speed="%d" rateofFire="%d" force="%d" bulletStrength="%d" cost="%d" type="%s" tag="%s">', no,count,speed,rateofFire,force,bulletStrength,cost,type, tag)];  
    txt = [txt, sprintf('\t\t</Tower>')];
    txt = [txt, sprintf('\t</SetTowers>')];
end